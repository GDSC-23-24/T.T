backend spring set - envrionment variables

please copy and paste below content

BUCKET=tt_solution_challenge;DB_ENDPOINT=tt-database.c5gkuy486so2.ap-northeast-2.rds.amazonaws.com;DB_PASSWORD=challenge1234;DB_PORT=3306;DB_SCHEMA=tt;DB_USERNAME=admin;LOCATION=D:\gdsc\solution-challenge\black-abode-413608-b02aa8db487c.json;PROJECT_ID=black-abode-413608


also you need to modify "LOCATION" values to your own directory
I will provide you with the json file.


react native set

Change the 'API_key' value in T.T\front\android\app\src\main\AndroidManifest.xml file andT.T\front\Screens\Map\Main.js file to the actual API value. Please.

node -v
v18.18.2

jdk - version : 17

sdk(api level); 30

pixel 3a 1080*2220